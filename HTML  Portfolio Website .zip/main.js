document.addEventListener("DOMContentLoaded", () => {
  const fadeEls = document.querySelectorAll(".animate-fade");

  const fadeInOnScroll = () => {
    fadeEls.forEach(el => {
      const top = el.getBoundingClientRect().top;
      if (top < window.innerHeight - 100) {
        el.classList.add("visible");
      }
    });
  };

  window.addEventListener("scroll", fadeInOnScroll);
  fadeInOnScroll(); // Initial check
});